import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyForm(),
    );
  }
}

class MyForm extends StatefulWidget {
  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  bool _isMarried = false;
  String _errorText = '';

  void _validateForm() {
    final name = _nameController.text;
    final age = _ageController.text;

    if (name.isEmpty) {
      setState(() {
        _errorText = 'Nama tidak boleh kosong.';
      });
    } else if (age.isEmpty || int.tryParse(age) == null) {
      setState(() {
        _errorText = 'Usia harus berupa angka.';
      });
    } else {
      setState(() {
        _errorText = '';
      });
      // Lakukan aksi yang Anda inginkan dengan data yang dimasukkan.
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text('Data yang Dimasukkan'),
            content: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Nama: $name'),
                Text('Usia: $age'),
                Text('Menikah: ${_isMarried ? 'Ya' : 'Tidak'}'),
              ],
            ),
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Formulir Flutter'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Nama'),
            ),
            TextField(
              controller: _ageController,
              decoration: InputDecoration(labelText: 'Usia'),
            ),
            Row(
              children: [
                Checkbox(
                  value: _isMarried,
                  onChanged: (value) {
                    setState(() {
                      _isMarried = value!;
                    });
                  },
                ),
                Text('Menikah'),
              ],
            ),
            Text(
              _errorText,
              style: TextStyle(color: Colors.red),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: _validateForm,
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
